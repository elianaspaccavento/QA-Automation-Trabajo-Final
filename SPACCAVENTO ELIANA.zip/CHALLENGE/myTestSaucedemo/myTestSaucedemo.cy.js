describe('Test Usuario 1 y 2', {testIsolation:false},() => {

// Ingreso al sitio web y login con user 1
    it('Login con el usuario "standard_user"', () => {
        cy.visit('https://www.saucedemo.com/v1/index.html');
        cy.get('input[name="user-name"]').type('standard_user');
        cy.get('input[name="password"]').type('secret_sauce');
        cy.get('#login-button').click();
        cy.wait(2000);
// Verificacion de que el usuario esta logueado correctamente
        cy.url().should('include', '/inventory.html');
       
    });
// Ingreso al carrito de compras y agregar productos al carrito
    it('ingreso al carrito', ()=>{
        cy.get('.product_label').contains('Products');
        cy.get(':nth-child(1) > .pricebar > .btn_primary').click();
        cy.get(':nth-child(2) > .pricebar > .btn_primary').click();
        cy.get(':nth-child(3) > .pricebar > .btn_primary').click();
        cy.get(':nth-child(4) > .pricebar > .btn_primary').click();
        cy.get(':nth-child(5) > .pricebar > .btn_primary').click();
        cy.get(':nth-child(6) > .pricebar > .btn_primary').click();
// Verificar que los productos esten añadidos al carrito
        cy.get('.shopping_cart_badge').should('be.visible');
    })
//Test para quitar productos del carrito
    it('Quitar productos del carrito de compras',()=>{
        cy.get(':nth-child(1) > .pricebar > .btn_secondary').click();
    })
//Checkout y formulario de envio
    it ('Realizar el checkout',()=>{
        cy.get('.shopping_cart_link').click();
        cy.get('.btn_action').click();
//Verificacion de que nos encontramos en la pagina del checkout
        cy.url().should('include', '/checkout-step-one.html')
        cy.get('#first-name').type('Eliana');
        cy.get('#last-name').type('Spaccavento');
        cy.get('#postal-code').type('1201');
        cy.get('.btn_primary').click();
        cy.get('.btn_action').click();
    })
//Validacion del checkout
    it('Validar que se haya realizado el checkout', () => { 
         cy.get('.complete-header').should('contain', 'THANK YOU FOR YOUR ORDER') })
//Realizar el Logout
    it('Realizar el logout',()=>{
        cy.get('.bm-burger-button > button').click();
        cy.get('#logout_sidebar_link').should('be.visible').click();
//Verificar que se redireccione al inicio luego del logout
        cy.url().should('include', '/');
    })


// Ingreso al sitio web y login con user 2


    it('Login con el usuario 2 "problem_user"', () => {
        cy.visit('https://www.saucedemo.com/v1/index.html');
        cy.get('input[name="user-name"]').type('problem_user');
        cy.get('input[name="password"]').type('secret_sauce');
        cy.get('#login-button').click();
        cy.wait(2000);  
    });
// Ingreso al carrito de compras y agregar productos al carrito
    it('ingreso al carrito', ()=>{
        cy.get('.product_label').contains('Products')
        cy.get(':nth-child(1) > .pricebar > .btn_primary').click()
        cy.get(':nth-child(2) > .pricebar > .btn_primary').click()
        cy.get(':nth-child(3) > .pricebar > .btn_primary').click()
        cy.get(':nth-child(4) > .pricebar > .btn_primary').click()
        cy.get(':nth-child(5) > .pricebar > .btn_primary').click()
        cy.get(':nth-child(6) > .pricebar > .btn_primary').click()
// Verificar que los productos esten añadidos al carrito
        cy.get('.shopping_cart_badge').should('be.visible');
    })
//Verificar que se puedan quitar los elementos del carrito de compras
    it('Quitar productos del carrito de compras',()=>{
        cy.get(':nth-child(1) > .pricebar > .btn_secondary').click();
    })
//Checkout y formulario de envio
   it ('Realizar el checkout',()=>{
        cy.get('.shopping_cart_link').click();
        cy.get('.btn_action').click();
//Verificacion de que nos encontramos en la pagina del checkout
        cy.url().should('include', '/checkout-step-one.html')
        cy.get('#first-name').type('Eliana');
        cy.get('#last-name').type('Spaccavento');
        cy.get('#postal-code').type('1201');
        cy.get('.btn_primary').click();
        cy.get('.btn_action').click();
    })
//Validacion del checkout
    it('Validar que se haya realizado el checkout', () => { 
    cy.get('.complete-header').should('contain', 'THANK YOU FOR YOUR ORDER') })
//Realizar el Logout
    it('Realizar el logout',()=>{
        cy.get('.bm-burger-button > button').click();
        cy.get('#logout_sidebar_link').should('be.visible').click();
//Verificar que se redireccione al inicio luego del logout
        cy.url().should('include', '/');
   })
})

  
  


   







